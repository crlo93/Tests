<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>REST</title>
  </head>
  <body>
    <a href="get.php">GET</a>
    <a href="post.php">POST</a>
    <a href="put.php">PUT</a>
    <a href="delete.php">DELETE</a>
  </body>
</html>
