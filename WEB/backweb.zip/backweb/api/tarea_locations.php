<!-- Se actualiza cada 30min  -->

<?php
// require_once 'example.php'; Cada archivos se ejecutara cada 30min de manera automatica
// require_once 'example1.php'; Cada archivos se ejecutara cada 30min de manera automatica
// require_once 'example2.php'; Cada archivos se ejecutara cada 30min de manera automatica
?>
