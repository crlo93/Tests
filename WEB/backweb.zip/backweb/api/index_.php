<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>RFW</title>
  </head>
  <body>
    <h1>ROBO-FIGHT WORLD</h1>
    <h2>WEB SERVICE</h2>
    <a href="test/index.php">Tester</a>
  </body>
</html>
