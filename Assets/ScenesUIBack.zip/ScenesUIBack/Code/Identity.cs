﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public enum Jenis {pRUEBA, ayam}

public class Identity : MonoBehaviour {

    public Jenis jenis;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
